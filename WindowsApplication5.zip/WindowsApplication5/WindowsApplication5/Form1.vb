﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Threading
Imports MySql.Data.MySqlClient
Public Class Form1
    Delegate Sub settextcallback(ByVal logout As String, ByVal append As Boolean)
    Dim revData As String = ""
    Dim revData2 As String = ""
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub
    Public Sub StartListen()
        Dim myTCPlistenter As TcpListener
        Dim icount As Integer = 0
        Dim iport As Integer = CInt(LPort.Text)
        myTCPlistenter = New TcpListener(IPAddress.Any, iport)
        Dim Clientsocket As Socket
        myTCPlistenter.Start()
        Do
            Clientsocket = myTCPlistenter.AcceptSocket

            If (Clientsocket.Connected) Then
                ' Dim myobj As New Car_point
                'myobj.idx = icount

                settext("Port:" + iport.ToString + "有一新連線" + IPAddress.Parse(CType(Clientsocket.RemoteEndPoint, IPEndPoint).Address.ToString()).ToString + vbCrLf, True)


                Dim ReceiveThread As New Thread(AddressOf ReceiveData)
                ReceiveThread.IsBackground = True
                ReceiveThread.Start(Clientsocket)
                icount += 1
            End If
        Loop
    End Sub

    Dim Read_Err_Count As Integer = 0
    Dim this_thread_idx As Integer = 0
    Dim thread_idx As Integer
    Dim windystr As String = ""
    Dim offset As Integer = 0
    Public Sub ReceiveData(ByVal Client_socket As Object)
        Dim socket_Client As Socket = CType(Client_socket, Socket)

        Dim stream As NetworkStream = New NetworkStream(socket_Client)
        Dim data(3000) As Byte
        Dim len As Integer = 0
        stream.ReadTimeout = 1000
        While Read_Err_Count < 100
            If this_thread_idx = thread_idx Then
                Try
                    Dim doworklog As String = ""
                    Dim s As String = ""
                    ReDim data(3000)
                    len = stream.Read(data, offset, 3000) '讀取資料

                    s = System.Text.Encoding.UTF8.GetString(data, 0, len)
                    windystr += s
                    settext(s)
                    Thread.Sleep(200)
                Catch ex As Exception
                    Exit While
                End Try


            Else

                Exit While
            End If
        End While
        socket_Client.Close()
    End Sub
    Dim Log_txt_cnt As Integer = 0
    Sub settext(ByVal logout As String, Optional ByVal append As Boolean = True, Optional ByVal car_no As Integer = 0)
        Try
            If Not logout = "" Then
                If Me.TextBox1.InvokeRequired Then
                    Dim d As New settextcallback(AddressOf settext)
                    Me.Invoke(d, New Object() {logout, append})
                ElseIf append = True Then
                    Me.TextBox1.AppendText(logout + vbCrLf)
                    Log_txt_cnt += 1
                    If Log_txt_cnt > 100 Then
                        Log_txt_cnt = 1
                        Me.TextBox1.Text = ""
                    End If
                Else
                    Me.TextBox1.Text = logout + vbCrLf
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ListenThread As New Thread(AddressOf StartListen)
        ListenThread.IsBackground = True
        ListenThread.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim a() As String
        a = windystr.Split(New Char() {Chr(2), Chr(3)}, StringSplitOptions.RemoveEmptyEntries)
        TextBox2.Text = ""
        If a.Length > 0 Then

        End If

        For i As Integer = 0 To a.Length - 1
            If a(i).StartsWith("Q") And a(i).EndsWith(",") Then
                If i = 0 Then
                    Dim temp() As String = a(i).Split(",")
                    If temp.Length > 6 And Not temp(1) = "" And Not temp(2) = "" And Not temp(3) = "" Then
                        Update_SQL("INSERT INTO `wind` (`Curr_time` ,`tagid` ,`X` ,`Y` ,`Z` ,`WindAngle` ,`windspeed` ,`windW`,Status)      select now(),Position,AGV_X,AGV_Y,AGV_TH," + temp(1) + "," + temp(2) + "," + temp(3) + ",Status from agv_list where AGVNo=1")
                        TextBox3.Text = temp(1).ToString
                        TextBox4.Text = temp(2).ToString
                        TextBox5.Text = temp(3).ToString

                        TextBox6.Text = Math.Atan(CDbl(temp((3)) / CDbl(temp(2)))) / Math.PI * 180
                    End If
                End If
                windystr = ""
            End If
            TextBox2.Text += i.ToString + ":" + a(i) + vbCrLf
        Next
    End Sub

    Function Update_SQL(ByVal Query As String)
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        Dim Mysql_str As String = "charset=utf8 ;Database=agv; Data Source=127.0.0.1;User id=agvc;Password=agvc; Allow Zero Datetime=True;"
        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        sqlCommand.CommandText = Query
        Try
            Update_SQL = sqlCommand.ExecuteNonQuery()
        Catch ex As Exception
            Update_SQL = 0
        End Try

        oConn.Close()
        oConn.Dispose()

    End Function
End Class
