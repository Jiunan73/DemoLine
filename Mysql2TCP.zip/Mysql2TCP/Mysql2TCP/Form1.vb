﻿Imports System.Net
Imports System.Net.Sockets
Imports MySql.Data.MySqlClient
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim DemoLineTcp As TcpClient = New TcpClient
        Dim DemoLinestream As NetworkStream
        Dim SendByte() As Byte
        DemoLineTcp.Connect("192.168.2.170", 4001)
        DemoLinestream = DemoLineTcp.GetStream
        SendByte = System.Text.Encoding.UTF8.GetBytes(TextBox1.Text)
        DemoLinestream.Write(SendByte, 0, SendByte.Length)
        DemoLinestream.Close()
        DemoLineTcp.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub
    Dim cnt As Integer = 0
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        cnt += 1
        If cnt > 10 Then
            cnt = 0
            Button2_Click(sender, e)
        End If

        Dim Mysql_str As String = "charset=utf8 ;Database=agv; Data Source=127.0.0.1;User id=agvc;Password=agvc; Allow Zero Datetime=True;"
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        Dim Query = ""
        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        Query = "INSERT ignore INTO  battery (`SerialNo`,`CarNo`,`FirstTime`) SELECT `bat_SN1`,`AGVNo`,now() " + _
        " FROM(agv_list) " + _
        " WHERE `bat_SN1` NOT IN (SELECT `SerialNo` FROM battery) and LENGTH(bat_SN1) > 5 ;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "INSERT ignore INTO battery (`SerialNo`,`CarNo`,`FirstTime`) SELECT `bat_SN2`,`AGVNo`,now() " + _
                " FROM(agv_list) " + _
                " WHERE `bat_SN2` NOT IN (SELECT `SerialNo` FROM battery) and LENGTH(bat_SN2)> 5 ;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "update `battery` A,agv_list B set A.`CHG_AH`=B.CHG_AH1,A.`DSG_AH`=B.`DSG_AH1`,A.`CYCLE`=B.`CYCLE1`,A.`SOH`=B.`SOH1`,A.LC_time=if(B.CarWork=48,now(),A.LC_time) WHERE A.`SerialNo`=B.`bat_SN1` and B.`CYCLE1` >0"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "update `battery` A,agv_list B set A.`CHG_AH`=B.CHG_AH2,A.`DSG_AH`=B.`DSG_AH2`,A.`CYCLE`=B.`CYCLE2`,A.`SOH`=B.`SOH2`,A.LC_time=if(B.CarWork=48,now(),A.LC_time) WHERE A.`SerialNo`=B.`bat_SN2` and B.`CYCLE2` >0"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()






        Query = "INSERT ignore INTO battery_history (`cmdkey`,`SerialNo`,`CarNo`,`Charger_time`,End_time,`Start_SOC`,End_SOC) SELECT `cmdkey`,`bat_SN1`,AGVNo,now(),now(),SOC1,SOC1 FROM agv_list  WHERE concat(`bat_SN1`,`cmdkey`) NOT IN (SELECT concat(`SerialNo`,`cmdkey`) FROM battery_history)  and `CarWork`=48 and LENGTH(bat_SN1)> 5"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "INSERT ignore INTO battery_history (`cmdkey`,`SerialNo`,`CarNo`,`Charger_time`,End_time,`Start_SOC`,End_SOC) SELECT `cmdkey`,`bat_SN2`,AGVNo,now(),now(),SOC2,SOC2 FROM(agv_list) WHERE concat(`bat_SN2`,`cmdkey`) NOT IN (SELECT concat(`SerialNo`,`cmdkey`) FROM battery_history)  and `CarWork`=48 and LENGTH(bat_SN2)> 5"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "update `battery_history` A,agv_list B  set A.End_SOC=B.SOC1,A.`End_time`=now()  WHERE A.`SerialNo`=B.`bat_SN1` and A.cmdkey=B.cmdkey and B.CarWork=48 and LENGTH(B.bat_SN1)> 5"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "update `battery_history` A,agv_list B set A.End_SOC=B.SOC2,A.`End_time`=now()  WHERE A.`SerialNo`=B.`bat_SN2` and A.cmdkey=B.cmdkey and B.CarWork=48 and LENGTH(B.bat_SN2)> 5 "
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        '均充
        Query = "INSERT ignore INTO  battery (`SerialNo`,`CarNo`,`FirstTime`) SELECT `bms1_fw`,`tagid`,now()  FROM `charger_status`  WHERE `bms1_fw` NOT IN (SELECT `SerialNo` FROM battery) and LENGTH(bms1_fw) > 5 and AutoStatus=3 ;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "INSERT ignore INTO  battery (`SerialNo`,`CarNo`,`FirstTime`) SELECT `bms2_fw`,`tagid`,now()  FROM `charger_status`  WHERE `bms2_fw` NOT IN (SELECT `SerialNo` FROM battery) and LENGTH(bms2_fw) > 5 and AutoStatus=3 ;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()


        Query = "update `battery` A,charger_status B set A.CarNo=B.tagid,A.`CHG_AH`=B.CHG_AH1,A.`DSG_AH`=B.`DSG_AH1`,A.`CYCLE`=B.`CYCLE1`,A.`SOH`=B.`SOH1`,A.LC_time=if(B.AutoStatus=3,now(),A.LC_time) WHERE A.`SerialNo`=B.`bms1_fw` and B.`CYCLE1` >0;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "update `battery` A,charger_status B set A.CarNo=B.tagid,A.`CHG_AH`=B.CHG_AH2,A.`DSG_AH`=B.`DSG_AH2`,A.`CYCLE`=B.`CYCLE2`,A.`SOH`=B.`SOH2`,A.LC_time=if(B.AutoStatus=3,now(),A.LC_time) WHERE A.`SerialNo`=B.`bms2_fw` and B.`CYCLE2` >0;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "INSERT ignore INTO battery_history (`cmdkey`,`SerialNo`,`CarNo`,`Charger_time`,End_time,`Start_SOC`,End_SOC) SELECT date_format(now(),'%Y%m%d'),`bms1_fw`,tagid,now(),now(),SOC1,SOC1 FROM charger_status  WHERE concat(`bms1_fw`,date_format(now(),'%Y%m%d')) NOT IN (SELECT concat(`SerialNo`,cmdkey) FROM battery_history)  and `AutoStatus`=3 and LENGTH(bms1_fw)> 5;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "INSERT ignore INTO battery_history (`cmdkey`,`SerialNo`,`CarNo`,`Charger_time`,End_time,`Start_SOC`,End_SOC) SELECT date_format(now(),'%Y%m%d'),`bms2_fw`,tagid,now(),now(),SOC2,SOC2 FROM charger_status  WHERE concat(`bms2_fw`,date_format(now(),'%Y%m%d')) NOT IN (SELECT concat(`SerialNo`,cmdkey) FROM battery_history)  and `AutoStatus`=3 and LENGTH(bms2_fw)> 5;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "update `battery_history` A,charger_status B  set A.End_SOC=B.SOC1,A.`End_time`=now()  WHERE A.`SerialNo`=B.`bms1_fw` and A.cmdkey=date_format(now(),'%Y%m%d') and B.AutoStatus=3 and LENGTH(B.bms1_fw)> 5;"
        sqlCommand.CommandText = Query
        sqlCommand.ExecuteNonQuery()

        Query = "update `battery_history` A,charger_status B  set A.End_SOC=B.SOC2,A.`End_time`=now()  WHERE A.`SerialNo`=B.`bms2_fw` and A.cmdkey=date_format(now(),'%Y%m%d') and B.AutoStatus=3 and LENGTH(B.bms2_fw)> 5;        sqlCommand.CommandText = Query"
        sqlCommand.ExecuteNonQuery()


        oConn.Close()
        oConn.Dispose()

    End Sub
    Sub Send2OA(ByVal str As String)
        Dim DemoLineTcp As TcpClient = New TcpClient
        Dim DemoLinestream As NetworkStream
        Dim SendByte() As Byte
        TextBox1.Text = str
        DemoLineTcp.Connect("192.168.2.170", 4001)
        DemoLinestream = DemoLineTcp.GetStream
        SendByte = System.Text.Encoding.UTF8.GetBytes(TextBox1.Text)
        DemoLinestream.Write(SendByte, 0, SendByte.Length)

        DemoLinestream.Close()
        DemoLineTcp.Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim Mysql_str As String = "charset=utf8 ;Database=agv; Data Source=127.0.0.1;User id=agvc;Password=agvc; Allow Zero Datetime=True;"
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        Dim dbreader As MySqlDataReader
        Dim Query = ""
        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn

        Query = "SELECT SerialNo, CarNo, SOH, CHG_AH, DSG_AH, CYCLE, DATE_FORMAT( LC_time, '%Y-%m-%d %H:%i:%s' ) FROM `battery` where LENGTH(SerialNo) > 5"
        sqlCommand.CommandText = Query
        dbreader = sqlCommand.ExecuteReader
        While (dbreader.Read)
            Dim SerialNo, CarNo, SOH, CHG_AH, DSG_AH, CYCLE, LC_time As String

            SerialNo = dbreader.Item(0).ToString
            CarNo = dbreader.Item(1).ToString
            SOH = dbreader.Item(2).ToString
            CHG_AH = dbreader.Item(3).ToString
            DSG_AH = dbreader.Item(4).ToString
            CYCLE = dbreader.Item(5).ToString
            LC_time = dbreader.Item(6).ToString
            Query = "INSERT ignore INTO  battery (`SerialNo`,`CarNo`,`FirstTime`) values('" + SerialNo + "'," + CarNo + ",now());"
            Send2OA(Query)
            Threading.Thread.Sleep(1000)
            ' If CInt(CYCLE) > 0 Then
            Query = "update `battery` A set A.CarNo=" + CarNo + ",A.`CHG_AH`=" + CHG_AH + ",A.`DSG_AH`=" + DSG_AH + ",A.`CYCLE`=" + CYCLE + ",A.`SOH`=" + SOH + ",A.LC_time='" + LC_time + "' WHERE A.`SerialNo`='" + SerialNo + "'; "
            Send2OA(Query)
            '  End If
            Application.DoEvents()
            Threading.Thread.Sleep(1000)
        End While
        dbreader.Close()

        Query = "SELECT cmdkey,SerialNo,CarNo,DATE_FORMAT( Charger_time, '%Y-%m-%d %H:%i:%s' ),DATE_FORMAT( End_time, '%Y-%m-%d %H:%i:%s' ),Start_SOC,End_SOC FROM `battery_history` WHERE `Charger_time` > DATE_SUB( NOW( ) , INTERVAL 2 DAY ) and `End_time` < DATE_SUB( NOW( ) , INTERVAL 1 HOUR ) "
        sqlCommand.CommandText = Query
        dbreader = sqlCommand.ExecuteReader
        While (dbreader.Read)
            Dim cmdkey, SerialNo, CarNo, Charger_time, End_time, Start_SOC, End_SOC As String
            cmdkey = dbreader.Item(0).ToString
            SerialNo = dbreader.Item(1).ToString
            CarNo = dbreader.Item(2).ToString
            Charger_time = dbreader.Item(3).ToString
            End_time = dbreader.Item(4).ToString
            Start_SOC = dbreader.Item(5).ToString
            End_SOC = dbreader.Item(6).ToString

            Query = "INSERT ignore INTO  battery_history (cmdkey,SerialNo,CarNo,Charger_time,End_time,Start_SOC,End_SOC) values('" + cmdkey + "','" + SerialNo + "'," + CarNo + ",'" + Charger_time + "','" + End_time + "'," + Start_SOC + "," + End_SOC + ");"
            Send2OA(Query)
            Threading.Thread.Sleep(1000)
       
        End While

        oConn.Close()
        oConn.Dispose()
    End Sub
End Class
