﻿Imports TwinCAT.Ads
Public Class Form1
    Dim client As TwinCAT.Ads.TcAdsClient
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        client = New TcAdsClient
        client.Connect(TextBox2.Text, 851)
        client.WriteSymbol("GVL.BatteryBMSHartBitWatchDogTime", CInt(TextBox1.Text), False)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim a As Boolean
        Dim x As ITcAdsSymbol
        client = New TcAdsClient
        client.Connect(TextBox2.Text, 851)


        'x = client.ReadSymbolInfo("GVL.PLCHartBitWatchDogTimer")
        x = client.ReadSymbolInfo("GVL.FX5U_Device1_Comm.nCar_PositionX")
        TextBox3.Text = client.ReadSymbol(x).ToString
    End Sub
End Class
