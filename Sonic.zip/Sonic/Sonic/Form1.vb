﻿Imports MySql.Data.MySqlClient
Imports System.Net
Imports System.Net.Sockets
Imports System.Threading
Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '  SerialPort1.Open()
        Dim ListenThread As New Thread(AddressOf StartListen)
        ListenThread.IsBackground = True
        ListenThread.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'TextBox1.Text = SerialPort1.ReadExisting
    End Sub
    Dim str As String
    Dim DataReceivedstr As String

    Private Sub SerialPort1_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        DataReceivedstr += SerialPort1.ReadExisting
        If DataReceivedstr.Contains(vbLf) Then

            Dim Query = ""

            Dim parts() As String = DataReceivedstr.Split(vbLf)
            For i As Integer = 0 To parts.Length - 2
                Dim data As String = parts(i)



                ' 在这里执行对每个完整数据的处理，比如打印到文本框
                TextBox1.Invoke(Sub() txtsp(data))
            Next
            DataReceivedstr = parts(parts.Length - 1)


        End If

    End Sub
    Dim cnt As Integer = 0
    Sub txtsp(ByVal str As String)
        Dim list() As String = str.Split(",")
        Dim Mysql_str As String = "charset=utf8 ;Database=agv; Data Source=127.0.0.1;User id=agvc;Password=agvc; Allow Zero Datetime=True;"
        TextBox1.Text = (str & vbCrLf)
        If list.Length > 18 Then

            TextBox1.Text += "三秒平均" + vbCrLf
            If list(17).StartsWith("Z") And list(18).StartsWith("Z") And list(19).StartsWith("Z") Then
                cnt += 1
                If cnt > 10 Then
                    cnt = 0
                    Dim oConn As MySqlConnection
                    Dim sqlCommand As New MySqlCommand
                    Dim Query = ""
                    oConn = New MySqlConnection(Mysql_str)
                    oConn.Open()

                    sqlCommand.Connection = oConn
                    Query = "INSERT INTO `agv`.`wind` (`Curr_time`, `tagid`, `X`, `Y`, `Z`, `WindAngle`, `windspeed`, `windW`, `Status`, `elevation_angle`) " + _
                    "VALUES (CURRENT_TIMESTAMP, '" + TextBox5.Text + "', '" + TextBox2.Text + "', '" + TextBox3.Text + "', '" + TextBox4.Text + "', '" + list(14).ToString + "', '" + list(13).ToString + "', '" + list(15).ToString + "', '', '" + list(16).ToString + "');"
                    sqlCommand.CommandText = Query

                    sqlCommand.ExecuteNonQuery()
                    oConn.Close()
                    oConn.Dispose()

                End If
                For i As Integer = 13 To 16
                    TextBox1.Text += list(i) + vbCrLf
                Next
            End If
        End If
        TextBox1.Text += "info" + vbCrLf
        For i As Integer = 0 To list.Length - 1
            TextBox1.Text += list(i) + vbCrLf

        Next


    End Sub
    Public Sub StartListen()
        Dim myTCPlistenter As TcpListener
        Dim icount As Integer = 0
        Dim iport As Integer = 5002
        myTCPlistenter = New TcpListener(IPAddress.Any, iport)
        Dim Clientsocket As Socket
        myTCPlistenter.Start()
        Do
            Clientsocket = myTCPlistenter.AcceptSocket

            If (Clientsocket.Connected) Then
                ' Dim myobj As New Car_point
                'myobj.idx = icount
                TextBox6.Invoke(Sub() TextBox6.AppendText("Port:" + iport.ToString + "有一新連線" + IPAddress.Parse(CType(Clientsocket.RemoteEndPoint, IPEndPoint).Address.ToString()).ToString + vbCrLf))
              
                Dim ReceiveThread As New Thread(AddressOf ReceiveData)
                ReceiveThread.IsBackground = True
                ReceiveThread.Start(Clientsocket)
                icount += 1
            End If
        Loop
    End Sub
    Dim threadidx As String = ""
    Public Sub ReceiveData(ByVal Client_socket As Object)
        Dim socket_Client As Socket = CType(Client_socket, Socket)
        Dim myReceiveBytes(1023) As Byte

        Dim wByte(1023) As Byte
        Dim R_str As String = ""
        Dim Temp_str As String = ""
        Dim cmd_stream = New NetworkStream(socket_Client)
        cmd_stream.ReadTimeout = 1000
        Dim rByte(1023) As Byte
        Dim len As Integer = 0
        threadidx = Now.ToString("yyyyMMddHHmmssfff")
        Dim thread_idx As String = Now.ToString("yyyyMMddHHmmssfff")

        While (1)

            Try

                len = cmd_stream.Read(rByte, 0, 1023)
            Catch ex As Exception

            End Try

            DataReceivedstr += System.Text.Encoding.UTF8.GetString(rByte, 0, len)
            If DataReceivedstr.Contains(vbLf) Then

                Dim Query = ""

                Dim parts() As String = DataReceivedstr.Split(vbLf)
                For i As Integer = 0 To parts.Length - 2
                    Dim data As String = parts(i)



                    ' 在这里执行对每个完整数据的处理，比如打印到文本框
                    TextBox1.Invoke(Sub() txtsp(data))
                Next
                DataReceivedstr = parts(parts.Length - 1)


            End If

            If threadidx <> thread_idx Then
                TextBox6.Invoke(Sub() TextBox6.AppendText("離開迴圈"))
                Exit While
            End If

        End While

        cmd_stream.Close()
        socket_Client.Close()

        '全部車子搜尋


    End Sub
End Class
