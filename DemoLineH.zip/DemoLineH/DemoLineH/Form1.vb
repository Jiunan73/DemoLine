﻿Imports EasyModbus
Imports System.Timers
Imports MySql.Data.MySqlClient
Public Class Form1
    Public Mysql_str As String = "charset=utf8 ;Database=agv; Data Source=127.0.0.1;User id=agvc;Password=agvc; Allow Zero Datetime=True;"
    Dim modbusClient As New ModbusClient("192.168.2.77", 502) ' 設定Modbus TCP伺服器的IP與Port
    Dim readRegisters1000(19) As Integer
    Dim readRegisters1100(19) As Integer
    Dim writeRegisters1200(19) As Integer
    Dim writeRegisters1300(19) As Integer
    Dim readRegisters1400(19) As Integer
    Dim writeRegisters1500(19) As Integer
    Dim Car As New Dictionary(Of Integer, car_point)()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'modbusClient.Connect()
        Timer1.Interval = 1000
        Timer1.Start()
    End Sub
    Dim step_i As Integer = -2
    Dim CV1_data As String = ""
    Dim inout As String = "IN"
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Not BackgroundWorker1.IsBusy Then
            BackgroundWorker1.RunWorkerAsync()
        End If
        Dim CV1_DI_Bit() As Boolean = int2bit(readRegisters1000(0))
        Dim CV1_DO_Bit() As Boolean = int2bit(writeRegisters1200(0))

        Dim CV2_DI_Bit() As Boolean = int2bit(readRegisters1100(0))
        Dim CV2_DO_Bit() As Boolean = int2bit(writeRegisters1300(0))
        Label2.Text = step_i.ToString
        If writeRegisters1500(0) = 0 Then
            writeRegisters1500(0) = 1
        Else
            writeRegisters1500(0) = 0
        End If
        writeRegisters1200(10) = 1 '棧板種類

        set_id(writeRegisters1200, CV1_data, 12, 5)
        If Car.ContainsKey(7) Then


            Select Case step_i
                Case -2
                    CV1_DO_Bit(0) = True 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                Case -1
                    '判斷狀態
                    CV1_DO_Bit(0) = True 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE

                    If CV1_DI_Bit(0) And CV1_DI_Bit(10) And CV1_DI_Bit(15) Then
                        'L-mode  放貨 將棧板放上EQ 
                        step_i = 1

                    ElseIf CV1_DI_Bit(0) And CV1_DI_Bit(11) And CV1_DI_Bit(15) Then
                        'UL-Mode Lreq 取貨
                        step_i = 11

                    ElseIf CV1_DI_Bit(15) And CV1_DI_Bit(10) And CV1_DI_Bit(10) Then
                        'UL-mode UP-REQ
                    End If


                Case 1
                    If CV1_DI_Bit(0) And CV1_DI_Bit(15) Then
                        'L-Req
                        CV1_data = "123456"
                        '派車
                        Send_CMD(7, 3, 520, "", "AGVC", 99)

                        Send_CMD(7, 1, 510, "", "AGVC", 95)
                        Send_CMD(7, 1, 5, "37,0,0", "AGVC", 90)
                        ' 
                        step_i = 2
                    End If
                Case 2

                    '判斷車子到了
                    If Car(7).cmdcnt = 0 And Car(7).Loading = 3 And Car(7).Position = 510 And Car(7).AGVAction = 0 Then
                        step_i = 3
                    End If
                Case 3
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = False 'Busy
                    CV1_DO_Bit(3) = False 'complete
                    If CV1_DI_Bit(4) Then
                        'ready
                        Send_CMD(7, 1, 511, "", "AGVC", 99)
                        Send_CMD(7, 1, 5, "37,0,0", "AGVC", 90)

                        step_i = 4
                        '派車
                    End If
                Case 4
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = True 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    '檢查車子到了沒
                    If Car(7).cmdcnt = 0 And Car(7).Position = 511 And Car(7).AGVAction = 0 Then
                        step_i = 5
                    End If
                Case 5
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = True 'COMPLETE
                    If CV1_DI_Bit(4) = False Then 'Ready off

                        step_i = 6
                    End If
                Case 6
                    'UL-REQ
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    If CV1_DI_Bit(1) And CV1_DI_Bit(10) And CV1_DI_Bit(15) Then
                        'UL-REQ 
                        step_i = 7
                    End If
                Case 7
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    If CV1_DI_Bit(4) Then
                        'ready

                        '派車
                        Send_CMD(7, 1, 510, "", "AGVC", 99)
                        step_i = 8
                    End If
                Case 8
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = True 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    If Car(7).Position = 510 Then
                        '判斷車子離開
                        step_i = 9
                        CV1_data = ""
                        Send_CMD(7, 1, 510, "", "AGVC", 99)
                    End If
                Case 9
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = True 'COMPLETE
                    If CV1_DI_Bit(4) = False Then
                        CV1_DO_Bit(0) = False 'SC
                        CV1_DO_Bit(1) = False 'TR
                        CV1_DO_Bit(2) = False 'BUSY
                        CV1_DO_Bit(3) = False 'COMPLETE
                        step_i = -1
                    End If

                    ' UL-MODE
                Case 11
                    If CV1_DI_Bit(0) And CV1_DI_Bit(15) Then
                        'L-Req
                        step_i = 12
                        Send_CMD(7, 1, 510, "", "AGVC", 95)
                        Send_CMD(7, 1, 5, "37,0,0", "AGVC", 90)
                    End If
                Case 12
                    If Car(7).cmdcnt = 0 And Car(7).Loading = 0 And Car(7).Position = 510 And Car(7).AGVAction = 0 Then
                        step_i = 13
                    End If

                    '判斷車子到了
                Case 13
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = False 'Busy
                    CV1_DO_Bit(3) = False 'complete
                    If CV1_DI_Bit(4) Then
                        'ready
                        step_i = 14
                        '派車\
                        Send_CMD(7, 1, 511, "", "AGVC", 95)
                        Send_CMD(7, 1, 5, "37,0,0", "AGVC", 90)
                    End If
                Case 14
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = True 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    '檢查車子到了沒
                    If Car(7).cmdcnt = 0 And Car(7).Position = 511 And Car(7).AGVAction = 0 Then
                        step_i = 15
                    End If
                Case 15
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = True 'COMPLETE
                    If CV1_DI_Bit(4) = False Then 'Ready off

                        step_i = 16
                    End If
                Case 16
                    'UL-REQ
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    If CV1_DI_Bit(1) And CV1_DI_Bit(11) And CV1_DI_Bit(15) Then
                        'UL-REQ 
                        step_i = 17
                    End If
                Case 17
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    If CV1_DI_Bit(4) Then
                        'ready
                        step_i = 18
                        Send_CMD(7, 1, 510, "", "AGVC", 95)

                        '派車
                    End If
                Case 18
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = True 'TR
                    CV1_DO_Bit(2) = True 'BUSY
                    CV1_DO_Bit(3) = False 'COMPLETE
                    If Car(7).cmdcnt = 0 And Car(7).Position = 510 And Car(7).AGVAction = 0 Then
                        '判斷車子離開
                        Send_CMD(7, 2, 520, "", "AGVC", 95)
                        step_i = 19
                        CV1_data = ""
                    End If
                Case 19
                    CV1_DO_Bit(0) = False 'SC
                    CV1_DO_Bit(1) = False 'TR
                    CV1_DO_Bit(2) = False 'BUSY
                    CV1_DO_Bit(3) = True 'COMPLETE
                    If CV1_DI_Bit(4) = False Then
                        CV1_DO_Bit(0) = False 'SC
                        CV1_DO_Bit(1) = False 'TR
                        CV1_DO_Bit(2) = False 'BUSY
                        CV1_DO_Bit(3) = False 'COMPLETE
                        step_i = -1
                    End If
            End Select
        End If

        readRegisters1000(0) = bit2int(CV1_DI_Bit)
        writeRegisters1200(0) = bit2int(CV1_DO_Bit)
        readRegisters1100(0) = bit2int(CV2_DI_Bit)
        writeRegisters1300(0) = bit2int(CV2_DO_Bit)
        For i As Integer = 0 To 15

            ' 找出名稱為 "test" 的 Label
            Dim DI1Label As Label = Me.Controls.Find("CV1_DI" + i.ToString, True).FirstOrDefault()
            If CV1_DI_Bit(i) Then
                DI1Label.BackColor = Color.Green
            Else
                DI1Label.BackColor = Color.Gray
            End If
            Dim DO1Label As Label = Me.Controls.Find("CV1_DO" + i.ToString, True).FirstOrDefault()
            If CV1_DO_Bit(i) Then
                DO1Label.BackColor = Color.Green
            Else
                DO1Label.BackColor = Color.Gray
            End If

            Dim DI2Label As Label = Me.Controls.Find("CV2_DI" + i.ToString, True).FirstOrDefault()
            If CV2_DI_Bit(i) Then
                DI2Label.BackColor = Color.Green
            Else
                DI2Label.BackColor = Color.Gray
            End If
            Dim DO2Label As Label = Me.Controls.Find("CV2_DO" + i.ToString, True).FirstOrDefault()
            If CV2_DO_Bit(i) Then
                DO2Label.BackColor = Color.Green
            Else
                DO2Label.BackColor = Color.Gray
            End If
        Next
        car_info()
        TextBox2.Text = ""
        For i As Integer = 0 To 10
            TextBox2.Text += readRegisters1400(i).ToString + " "
        Next
    End Sub

    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Try
            If modbusClient.Connected Then


                readRegisters1000 = modbusClient.ReadHoldingRegisters(1000, 20)
                readRegisters1100 = modbusClient.ReadHoldingRegisters(1100, 20)
                readRegisters1400 = modbusClient.ReadHoldingRegisters(1400, 20)
                ' 將數據寫入 1100 與 1300
                modbusClient.WriteMultipleRegisters(1200, writeRegisters1200)
                modbusClient.WriteMultipleRegisters(1300, writeRegisters1300)
                modbusClient.WriteMultipleRegisters(1500, writeRegisters1500)
                Dim result As String = DateTime.Now.ToString("HH:mm:ss") & " - 讀寫成功" & Environment.NewLine
                Me.Invoke(Sub() TextBox1.AppendText(result))

            Else
                Me.Invoke(Sub() TextBox1.AppendText("連線中" + vbCrLf))
                modbusClient.Connect()
                Me.Invoke(Sub() TextBox1.AppendText("連線狀態:" + modbusClient.Connected.ToString + vbCrLf))
            End If
        Catch ex As Exception
            ' modbusClient.Connected
            modbusClient.Disconnect()
            Me.Invoke(Sub() TextBox1.AppendText("連線錯誤" + modbusClient.Connected.ToString + vbCrLf))
        End Try


    End Sub
    Function bit2int(ByVal bitary() As Boolean) As Integer
        bit2int = 0
        For i As Integer = 0 To bitary.Length - 1
            If bitary(i) Then
                bit2int += 2 ^ i
            End If

        Next
    End Function
    Function int2bit(ByVal val As Integer) As Boolean()

        Dim BitAry(15) As Boolean
        For i As Integer = 0 To BitAry.Length - 1

            BitAry(i) = (val >> i) And 1
        Next
        int2bit = BitAry
    End Function
    Function get_id(ByRef val() As Integer, ByVal start As Integer, ByVal cnt As Integer) As String
        get_id = ""
        '  Return device_status(17)
        'If get_loading() = 3 Then
        Dim id(cnt * 2 - 1) As Byte
        For i As Integer = 0 To cnt
            id(2 * i) = val(start + i) Mod 256
            id(2 * i + 1) = val(start + i) \ 256
        Next
        get_id = System.Text.Encoding.UTF8.GetString(id, 0, cnt * 2)
        get_id = get_id.TrimEnd("")

        'End If
    End Function
    Sub set_id(ByRef val() As Integer, ByVal str As String, ByVal start As Integer, ByVal cnt As Integer)

        Dim byteArray() As Byte = System.Text.Encoding.UTF8.GetBytes(str)
        Dim men(cnt * 2) As Byte
        For i As Integer = 0 To byteArray.Length - 1
            men(i) = byteArray(i)
        Next
        For i As Integer = 0 To cnt - 1

            val(i + start) = men(2 * i + 1) * 256 + men(2 * i)
        Next


    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        step_i += 1
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        car_info()


    End Sub

    Function Update_SQL(ByVal Query As String)
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        sqlCommand.CommandText = Query
        Try
            Update_SQL = sqlCommand.ExecuteNonQuery()
        Catch ex As Exception
            Update_SQL = 0
        End Try

        oConn.Close()
        oConn.Dispose()

    End Function
    Function Send_CMD(ByVal car_no As Integer, ByVal From_Point As Integer, ByVal To_Point As Integer, Optional ByVal ext_cmd As String = "", Optional ByVal user As String = "AGVC", Optional ByVal Pri_Wt As Integer = 50)
        Send_CMD = 0
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand

        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        Dim Query As String = ""
        Dim mysql_data As Object
        Try



            If From_Point < 10 Then

                Query = " insert into agv_cmd_list(AGVNo,CmdFrom,CmdTo,Pri_Wt,RequestTime,Requestor,RequestName,ext_cmd) VALUES('" + car_no.ToString + "'," + From_Point.ToString + "," + To_Point.ToString + "," + Pri_Wt.ToString + ",now(),'" + user + "','" + user + "','" + ext_cmd + "')	 "
               
                sqlCommand.CommandText = Query
                'Cmd_status.AppendText("Query=" + Query)
                Send_CMD = sqlCommand.ExecuteNonQuery()


                ' Cmd_status.AppendText(Query + ":" + Send_CMD.ToString + vbCrLf)
            Else
                Dim to_cnt, from_cnt As Integer
                Query = "select count(*) FROM `shelf_car` where LOCATION=" + From_Point.ToString
                sqlCommand.CommandText = Query
                mysql_data = sqlCommand.ExecuteScalar()
                from_cnt = CInt(mysql_data)
                'Cmd_status.AppendText(Query + ":" + from_cnt.ToString + vbCrLf)
                Query = "select count(*) FROM `shelf_car` where LOCATION=" + To_Point.ToString
                sqlCommand.CommandText = Query
                mysql_data = sqlCommand.ExecuteScalar()
                to_cnt = CInt(mysql_data)
                'Cmd_status.AppendText(Query + ":" + to_cnt.ToString + vbCrLf)
                If from_cnt = 1 And to_cnt = 0 Then
                    'TO 點位沒有架台
                    Query = "insert into  `agv_cmd_list`(`AGVNo`,`CmdFrom`,`CmdTo`,`Pri_Wt`,`Requestor`,`Shelf_Car_No`,`Shelf_Car_type`,`Shelf_Car_Size`) select '" + car_no.ToString + "' as AGVNo,'" + From_Point.ToString + "','" + To_Point.ToString + "'," + Pri_Wt.ToString + ",'" + user + "',Shelf_Car_No,`Shelf_Car_type`,`Shelf_Car_Size` from `shelf_car` where LOCATION='" + From_Point.ToString + "' "
                    sqlCommand.CommandText = Query
                    Send_CMD = sqlCommand.ExecuteNonQuery()
                    '  Cmd_status.AppendText(Query + ":" + Send_CMD.ToString + vbCrLf)
                ElseIf from_cnt = 0 Then
                    Send_CMD = 0
                    '   Cmd_status.AppendText("來源端無架台" + vbCrLf)
                ElseIf to_cnt = 1 Then
                    Send_CMD = 0
                    '  Cmd_status.AppendText("目的端架台" + vbCrLf)
                End If
            End If

        Catch ex As Exception
            Send_CMD = 0
            'Cmd_status.AppendText("Query=" + Query + ":" + ex.Message)
        End Try

        oConn.Close()
        oConn.Dispose()
    End Function
    Sub car_info()
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        Dim mReader As MySqlDataReader
        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        sqlCommand.CommandText = "select A.AGVNo,Position,Status,AGVAction,Loading,CarWork,count(B.AGVNo) FROM `agv_list` A LEFT JOIN agv_cmd_list B ON A.`AGVNo` = B.`AGVNo` group by A.AGVNo"
        mReader = sqlCommand.ExecuteReader()

        While (mReader.Read)
            Dim temp As car_point
            temp.carno = CInt(mReader.Item(0))
            temp.Position = CInt(mReader.Item(1))
            temp.Status = CInt(mReader.Item(2))
            temp.AGVAction = CInt(mReader.Item(3))
            temp.Loading = CInt(mReader.Item(4))
            temp.CarWork = CInt(mReader.Item(5))
            temp.cmdcnt = CInt(mReader.Item(6))
            If Car.ContainsKey(mReader.Item(0)) Then
                Car.Remove(CInt(mReader.Item(0)))
            End If
            Car.Add(CInt(mReader.Item(0)), temp)
        End While
        oConn.Close()
        oConn.Dispose()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        writeRegisters1500(1) = 2

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        writeRegisters1500(1) = 1
    End Sub
End Class
