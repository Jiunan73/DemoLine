﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.CV1_DI0 = New System.Windows.Forms.Label()
        Me.CV1_DI1 = New System.Windows.Forms.Label()
        Me.CV1_DI2 = New System.Windows.Forms.Label()
        Me.CV1_DI3 = New System.Windows.Forms.Label()
        Me.CV1_DI4 = New System.Windows.Forms.Label()
        Me.CV1_DI5 = New System.Windows.Forms.Label()
        Me.CV1_DI6 = New System.Windows.Forms.Label()
        Me.CV1_DI7 = New System.Windows.Forms.Label()
        Me.CV1_DI8 = New System.Windows.Forms.Label()
        Me.CV1_DI9 = New System.Windows.Forms.Label()
        Me.CV1_DI10 = New System.Windows.Forms.Label()
        Me.CV1_DI11 = New System.Windows.Forms.Label()
        Me.CV1_DI12 = New System.Windows.Forms.Label()
        Me.CV1_DI13 = New System.Windows.Forms.Label()
        Me.CV1_DI14 = New System.Windows.Forms.Label()
        Me.CV1_DI15 = New System.Windows.Forms.Label()
        Me.CV1_DO15 = New System.Windows.Forms.Label()
        Me.CV1_DO14 = New System.Windows.Forms.Label()
        Me.CV1_DO13 = New System.Windows.Forms.Label()
        Me.CV1_DO12 = New System.Windows.Forms.Label()
        Me.CV1_DO11 = New System.Windows.Forms.Label()
        Me.CV1_DO10 = New System.Windows.Forms.Label()
        Me.CV1_DO9 = New System.Windows.Forms.Label()
        Me.CV1_DO8 = New System.Windows.Forms.Label()
        Me.CV1_DO7 = New System.Windows.Forms.Label()
        Me.CV1_DO6 = New System.Windows.Forms.Label()
        Me.CV1_DO5 = New System.Windows.Forms.Label()
        Me.CV1_DO4 = New System.Windows.Forms.Label()
        Me.CV1_DO3 = New System.Windows.Forms.Label()
        Me.CV1_DO2 = New System.Windows.Forms.Label()
        Me.CV1_DO1 = New System.Windows.Forms.Label()
        Me.CV1_DO0 = New System.Windows.Forms.Label()
        Me.CV2_DI15 = New System.Windows.Forms.Label()
        Me.CV2_DI14 = New System.Windows.Forms.Label()
        Me.CV2_DI13 = New System.Windows.Forms.Label()
        Me.CV2_DI12 = New System.Windows.Forms.Label()
        Me.CV2_DI11 = New System.Windows.Forms.Label()
        Me.CV2_DI10 = New System.Windows.Forms.Label()
        Me.CV2_DI9 = New System.Windows.Forms.Label()
        Me.CV2_DI8 = New System.Windows.Forms.Label()
        Me.CV2_DI7 = New System.Windows.Forms.Label()
        Me.CV2_DI6 = New System.Windows.Forms.Label()
        Me.CV2_DI5 = New System.Windows.Forms.Label()
        Me.CV2_DI4 = New System.Windows.Forms.Label()
        Me.CV2_DI3 = New System.Windows.Forms.Label()
        Me.CV2_DI2 = New System.Windows.Forms.Label()
        Me.CV2_DI1 = New System.Windows.Forms.Label()
        Me.CV2_DI0 = New System.Windows.Forms.Label()
        Me.CV2_DO15 = New System.Windows.Forms.Label()
        Me.CV2_DO14 = New System.Windows.Forms.Label()
        Me.CV2_DO13 = New System.Windows.Forms.Label()
        Me.CV2_DO12 = New System.Windows.Forms.Label()
        Me.CV2_DO11 = New System.Windows.Forms.Label()
        Me.CV2_DO10 = New System.Windows.Forms.Label()
        Me.CV2_DO9 = New System.Windows.Forms.Label()
        Me.CV2_DO8 = New System.Windows.Forms.Label()
        Me.CV2_DO7 = New System.Windows.Forms.Label()
        Me.CV2_DO6 = New System.Windows.Forms.Label()
        Me.CV2_DO5 = New System.Windows.Forms.Label()
        Me.CV2_DO4 = New System.Windows.Forms.Label()
        Me.CV2_DO3 = New System.Windows.Forms.Label()
        Me.CV2_DO2 = New System.Windows.Forms.Label()
        Me.CV2_DO1 = New System.Windows.Forms.Label()
        Me.CV2_DO0 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(947, 488)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "連線"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'BackgroundWorker1
        '
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(74, 40)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(820, 411)
        Me.TextBox1.TabIndex = 1
        '
        'CV1_DI0
        '
        Me.CV1_DI0.Location = New System.Drawing.Point(900, 43)
        Me.CV1_DI0.Name = "CV1_DI0"
        Me.CV1_DI0.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI0.TabIndex = 2
        Me.CV1_DI0.Text = "L-Req"
        '
        'CV1_DI1
        '
        Me.CV1_DI1.Location = New System.Drawing.Point(900, 66)
        Me.CV1_DI1.Name = "CV1_DI1"
        Me.CV1_DI1.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI1.TabIndex = 3
        Me.CV1_DI1.Text = "UL-Req"
        '
        'CV1_DI2
        '
        Me.CV1_DI2.Location = New System.Drawing.Point(900, 87)
        Me.CV1_DI2.Name = "CV1_DI2"
        Me.CV1_DI2.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI2.TabIndex = 4
        Me.CV1_DI2.Text = "Label3"
        '
        'CV1_DI3
        '
        Me.CV1_DI3.Location = New System.Drawing.Point(900, 109)
        Me.CV1_DI3.Name = "CV1_DI3"
        Me.CV1_DI3.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI3.TabIndex = 5
        Me.CV1_DI3.Text = "-"
        '
        'CV1_DI4
        '
        Me.CV1_DI4.Location = New System.Drawing.Point(900, 132)
        Me.CV1_DI4.Name = "CV1_DI4"
        Me.CV1_DI4.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI4.TabIndex = 6
        Me.CV1_DI4.Text = "Ready"
        '
        'CV1_DI5
        '
        Me.CV1_DI5.Location = New System.Drawing.Point(900, 154)
        Me.CV1_DI5.Name = "CV1_DI5"
        Me.CV1_DI5.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI5.TabIndex = 7
        Me.CV1_DI5.Text = "Label6"
        '
        'CV1_DI6
        '
        Me.CV1_DI6.Location = New System.Drawing.Point(900, 177)
        Me.CV1_DI6.Name = "CV1_DI6"
        Me.CV1_DI6.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI6.TabIndex = 8
        Me.CV1_DI6.Text = "Label7"
        '
        'CV1_DI7
        '
        Me.CV1_DI7.Location = New System.Drawing.Point(900, 199)
        Me.CV1_DI7.Name = "CV1_DI7"
        Me.CV1_DI7.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI7.TabIndex = 9
        Me.CV1_DI7.Text = "Label8"
        '
        'CV1_DI8
        '
        Me.CV1_DI8.Location = New System.Drawing.Point(900, 221)
        Me.CV1_DI8.Name = "CV1_DI8"
        Me.CV1_DI8.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI8.TabIndex = 10
        Me.CV1_DI8.Text = "Load"
        '
        'CV1_DI9
        '
        Me.CV1_DI9.Location = New System.Drawing.Point(900, 243)
        Me.CV1_DI9.Name = "CV1_DI9"
        Me.CV1_DI9.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI9.TabIndex = 11
        Me.CV1_DI9.Text = "Label10"
        '
        'CV1_DI10
        '
        Me.CV1_DI10.Location = New System.Drawing.Point(900, 264)
        Me.CV1_DI10.Name = "CV1_DI10"
        Me.CV1_DI10.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI10.TabIndex = 12
        Me.CV1_DI10.Text = "L-Mode"
        '
        'CV1_DI11
        '
        Me.CV1_DI11.Location = New System.Drawing.Point(900, 287)
        Me.CV1_DI11.Name = "CV1_DI11"
        Me.CV1_DI11.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI11.TabIndex = 13
        Me.CV1_DI11.Text = "UL-Mode"
        '
        'CV1_DI12
        '
        Me.CV1_DI12.Location = New System.Drawing.Point(900, 309)
        Me.CV1_DI12.Name = "CV1_DI12"
        Me.CV1_DI12.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI12.TabIndex = 14
        Me.CV1_DI12.Text = "Label13"
        '
        'CV1_DI13
        '
        Me.CV1_DI13.Location = New System.Drawing.Point(900, 332)
        Me.CV1_DI13.Name = "CV1_DI13"
        Me.CV1_DI13.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI13.TabIndex = 15
        Me.CV1_DI13.Text = "Label14"
        '
        'CV1_DI14
        '
        Me.CV1_DI14.Location = New System.Drawing.Point(900, 353)
        Me.CV1_DI14.Name = "CV1_DI14"
        Me.CV1_DI14.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI14.TabIndex = 16
        Me.CV1_DI14.Text = "Label15"
        '
        'CV1_DI15
        '
        Me.CV1_DI15.Location = New System.Drawing.Point(900, 375)
        Me.CV1_DI15.Name = "CV1_DI15"
        Me.CV1_DI15.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DI15.TabIndex = 17
        Me.CV1_DI15.Text = "OnLine"
        '
        'CV1_DO15
        '
        Me.CV1_DO15.Location = New System.Drawing.Point(974, 375)
        Me.CV1_DO15.Name = "CV1_DO15"
        Me.CV1_DO15.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO15.TabIndex = 33
        Me.CV1_DO15.Text = "Label17"
        '
        'CV1_DO14
        '
        Me.CV1_DO14.Location = New System.Drawing.Point(974, 353)
        Me.CV1_DO14.Name = "CV1_DO14"
        Me.CV1_DO14.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO14.TabIndex = 32
        Me.CV1_DO14.Text = "Label18"
        '
        'CV1_DO13
        '
        Me.CV1_DO13.Location = New System.Drawing.Point(974, 332)
        Me.CV1_DO13.Name = "CV1_DO13"
        Me.CV1_DO13.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO13.TabIndex = 31
        Me.CV1_DO13.Text = "Label19"
        '
        'CV1_DO12
        '
        Me.CV1_DO12.Location = New System.Drawing.Point(974, 309)
        Me.CV1_DO12.Name = "CV1_DO12"
        Me.CV1_DO12.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO12.TabIndex = 30
        Me.CV1_DO12.Text = "Label20"
        '
        'CV1_DO11
        '
        Me.CV1_DO11.Location = New System.Drawing.Point(974, 287)
        Me.CV1_DO11.Name = "CV1_DO11"
        Me.CV1_DO11.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO11.TabIndex = 29
        Me.CV1_DO11.Text = "Label21"
        '
        'CV1_DO10
        '
        Me.CV1_DO10.Location = New System.Drawing.Point(974, 264)
        Me.CV1_DO10.Name = "CV1_DO10"
        Me.CV1_DO10.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO10.TabIndex = 28
        Me.CV1_DO10.Text = "Label22"
        '
        'CV1_DO9
        '
        Me.CV1_DO9.Location = New System.Drawing.Point(974, 243)
        Me.CV1_DO9.Name = "CV1_DO9"
        Me.CV1_DO9.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO9.TabIndex = 27
        Me.CV1_DO9.Text = "Label23"
        '
        'CV1_DO8
        '
        Me.CV1_DO8.Location = New System.Drawing.Point(974, 221)
        Me.CV1_DO8.Name = "CV1_DO8"
        Me.CV1_DO8.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO8.TabIndex = 26
        Me.CV1_DO8.Text = "Label24"
        '
        'CV1_DO7
        '
        Me.CV1_DO7.Location = New System.Drawing.Point(974, 199)
        Me.CV1_DO7.Name = "CV1_DO7"
        Me.CV1_DO7.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO7.TabIndex = 25
        Me.CV1_DO7.Text = "Label25"
        '
        'CV1_DO6
        '
        Me.CV1_DO6.Location = New System.Drawing.Point(974, 177)
        Me.CV1_DO6.Name = "CV1_DO6"
        Me.CV1_DO6.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO6.TabIndex = 24
        Me.CV1_DO6.Text = "Label26"
        '
        'CV1_DO5
        '
        Me.CV1_DO5.Location = New System.Drawing.Point(974, 154)
        Me.CV1_DO5.Name = "CV1_DO5"
        Me.CV1_DO5.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO5.TabIndex = 23
        Me.CV1_DO5.Text = "Label27"
        '
        'CV1_DO4
        '
        Me.CV1_DO4.Location = New System.Drawing.Point(974, 132)
        Me.CV1_DO4.Name = "CV1_DO4"
        Me.CV1_DO4.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO4.TabIndex = 22
        Me.CV1_DO4.Text = "Label28"
        '
        'CV1_DO3
        '
        Me.CV1_DO3.Location = New System.Drawing.Point(974, 109)
        Me.CV1_DO3.Name = "CV1_DO3"
        Me.CV1_DO3.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO3.TabIndex = 21
        Me.CV1_DO3.Text = "Complete"
        '
        'CV1_DO2
        '
        Me.CV1_DO2.Location = New System.Drawing.Point(974, 87)
        Me.CV1_DO2.Name = "CV1_DO2"
        Me.CV1_DO2.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO2.TabIndex = 20
        Me.CV1_DO2.Text = "Busy"
        '
        'CV1_DO1
        '
        Me.CV1_DO1.Location = New System.Drawing.Point(974, 66)
        Me.CV1_DO1.Name = "CV1_DO1"
        Me.CV1_DO1.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO1.TabIndex = 19
        Me.CV1_DO1.Text = "TR"
        '
        'CV1_DO0
        '
        Me.CV1_DO0.Location = New System.Drawing.Point(974, 43)
        Me.CV1_DO0.Name = "CV1_DO0"
        Me.CV1_DO0.Size = New System.Drawing.Size(55, 15)
        Me.CV1_DO0.TabIndex = 18
        Me.CV1_DO0.Text = "SC"
        '
        'CV2_DI15
        '
        Me.CV2_DI15.Location = New System.Drawing.Point(1077, 375)
        Me.CV2_DI15.Name = "CV2_DI15"
        Me.CV2_DI15.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI15.TabIndex = 49
        Me.CV2_DI15.Text = "OnLine"
        '
        'CV2_DI14
        '
        Me.CV2_DI14.Location = New System.Drawing.Point(1077, 353)
        Me.CV2_DI14.Name = "CV2_DI14"
        Me.CV2_DI14.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI14.TabIndex = 48
        Me.CV2_DI14.Text = "Label34"
        '
        'CV2_DI13
        '
        Me.CV2_DI13.Location = New System.Drawing.Point(1077, 332)
        Me.CV2_DI13.Name = "CV2_DI13"
        Me.CV2_DI13.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI13.TabIndex = 47
        Me.CV2_DI13.Text = "Label35"
        '
        'CV2_DI12
        '
        Me.CV2_DI12.Location = New System.Drawing.Point(1077, 309)
        Me.CV2_DI12.Name = "CV2_DI12"
        Me.CV2_DI12.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI12.TabIndex = 46
        Me.CV2_DI12.Text = "Label36"
        '
        'CV2_DI11
        '
        Me.CV2_DI11.Location = New System.Drawing.Point(1077, 287)
        Me.CV2_DI11.Name = "CV2_DI11"
        Me.CV2_DI11.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI11.TabIndex = 45
        Me.CV2_DI11.Text = "UL-Mode"
        '
        'CV2_DI10
        '
        Me.CV2_DI10.Location = New System.Drawing.Point(1077, 264)
        Me.CV2_DI10.Name = "CV2_DI10"
        Me.CV2_DI10.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI10.TabIndex = 44
        Me.CV2_DI10.Text = "L-Mode"
        '
        'CV2_DI9
        '
        Me.CV2_DI9.Location = New System.Drawing.Point(1077, 243)
        Me.CV2_DI9.Name = "CV2_DI9"
        Me.CV2_DI9.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI9.TabIndex = 43
        Me.CV2_DI9.Text = "Label39"
        '
        'CV2_DI8
        '
        Me.CV2_DI8.Location = New System.Drawing.Point(1077, 221)
        Me.CV2_DI8.Name = "CV2_DI8"
        Me.CV2_DI8.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI8.TabIndex = 42
        Me.CV2_DI8.Text = "InterLock"
        '
        'CV2_DI7
        '
        Me.CV2_DI7.Location = New System.Drawing.Point(1077, 199)
        Me.CV2_DI7.Name = "CV2_DI7"
        Me.CV2_DI7.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI7.TabIndex = 41
        Me.CV2_DI7.Text = "Label41"
        '
        'CV2_DI6
        '
        Me.CV2_DI6.Location = New System.Drawing.Point(1077, 177)
        Me.CV2_DI6.Name = "CV2_DI6"
        Me.CV2_DI6.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI6.TabIndex = 40
        Me.CV2_DI6.Text = "Label42"
        '
        'CV2_DI5
        '
        Me.CV2_DI5.Location = New System.Drawing.Point(1077, 154)
        Me.CV2_DI5.Name = "CV2_DI5"
        Me.CV2_DI5.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI5.TabIndex = 39
        Me.CV2_DI5.Text = "Label43"
        '
        'CV2_DI4
        '
        Me.CV2_DI4.Location = New System.Drawing.Point(1077, 132)
        Me.CV2_DI4.Name = "CV2_DI4"
        Me.CV2_DI4.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI4.TabIndex = 38
        Me.CV2_DI4.Text = "Ready"
        '
        'CV2_DI3
        '
        Me.CV2_DI3.Location = New System.Drawing.Point(1077, 109)
        Me.CV2_DI3.Name = "CV2_DI3"
        Me.CV2_DI3.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI3.TabIndex = 37
        Me.CV2_DI3.Text = "-"
        '
        'CV2_DI2
        '
        Me.CV2_DI2.Location = New System.Drawing.Point(1077, 87)
        Me.CV2_DI2.Name = "CV2_DI2"
        Me.CV2_DI2.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI2.TabIndex = 36
        Me.CV2_DI2.Text = "Label46"
        '
        'CV2_DI1
        '
        Me.CV2_DI1.Location = New System.Drawing.Point(1077, 66)
        Me.CV2_DI1.Name = "CV2_DI1"
        Me.CV2_DI1.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI1.TabIndex = 35
        Me.CV2_DI1.Text = "UL-Req"
        '
        'CV2_DI0
        '
        Me.CV2_DI0.Location = New System.Drawing.Point(1077, 43)
        Me.CV2_DI0.Name = "CV2_DI0"
        Me.CV2_DI0.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DI0.TabIndex = 34
        Me.CV2_DI0.Text = "L-Req"
        '
        'CV2_DO15
        '
        Me.CV2_DO15.Location = New System.Drawing.Point(1155, 375)
        Me.CV2_DO15.Name = "CV2_DO15"
        Me.CV2_DO15.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO15.TabIndex = 65
        Me.CV2_DO15.Text = "Label49"
        '
        'CV2_DO14
        '
        Me.CV2_DO14.Location = New System.Drawing.Point(1155, 353)
        Me.CV2_DO14.Name = "CV2_DO14"
        Me.CV2_DO14.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO14.TabIndex = 64
        Me.CV2_DO14.Text = "Label50"
        '
        'CV2_DO13
        '
        Me.CV2_DO13.Location = New System.Drawing.Point(1155, 332)
        Me.CV2_DO13.Name = "CV2_DO13"
        Me.CV2_DO13.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO13.TabIndex = 63
        Me.CV2_DO13.Text = "Label51"
        '
        'CV2_DO12
        '
        Me.CV2_DO12.Location = New System.Drawing.Point(1155, 309)
        Me.CV2_DO12.Name = "CV2_DO12"
        Me.CV2_DO12.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO12.TabIndex = 62
        Me.CV2_DO12.Text = "Label52"
        '
        'CV2_DO11
        '
        Me.CV2_DO11.Location = New System.Drawing.Point(1155, 287)
        Me.CV2_DO11.Name = "CV2_DO11"
        Me.CV2_DO11.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO11.TabIndex = 61
        Me.CV2_DO11.Text = "Label53"
        '
        'CV2_DO10
        '
        Me.CV2_DO10.Location = New System.Drawing.Point(1155, 264)
        Me.CV2_DO10.Name = "CV2_DO10"
        Me.CV2_DO10.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO10.TabIndex = 60
        Me.CV2_DO10.Text = "Label54"
        '
        'CV2_DO9
        '
        Me.CV2_DO9.Location = New System.Drawing.Point(1155, 243)
        Me.CV2_DO9.Name = "CV2_DO9"
        Me.CV2_DO9.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO9.TabIndex = 59
        Me.CV2_DO9.Text = "Label55"
        '
        'CV2_DO8
        '
        Me.CV2_DO8.Location = New System.Drawing.Point(1155, 221)
        Me.CV2_DO8.Name = "CV2_DO8"
        Me.CV2_DO8.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO8.TabIndex = 58
        Me.CV2_DO8.Text = "Label56"
        '
        'CV2_DO7
        '
        Me.CV2_DO7.Location = New System.Drawing.Point(1155, 199)
        Me.CV2_DO7.Name = "CV2_DO7"
        Me.CV2_DO7.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO7.TabIndex = 57
        Me.CV2_DO7.Text = "Label57"
        '
        'CV2_DO6
        '
        Me.CV2_DO6.Location = New System.Drawing.Point(1155, 177)
        Me.CV2_DO6.Name = "CV2_DO6"
        Me.CV2_DO6.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO6.TabIndex = 56
        Me.CV2_DO6.Text = "Label58"
        '
        'CV2_DO5
        '
        Me.CV2_DO5.Location = New System.Drawing.Point(1155, 154)
        Me.CV2_DO5.Name = "CV2_DO5"
        Me.CV2_DO5.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO5.TabIndex = 55
        Me.CV2_DO5.Text = "Label59"
        '
        'CV2_DO4
        '
        Me.CV2_DO4.Location = New System.Drawing.Point(1155, 132)
        Me.CV2_DO4.Name = "CV2_DO4"
        Me.CV2_DO4.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO4.TabIndex = 54
        Me.CV2_DO4.Text = "Label60"
        '
        'CV2_DO3
        '
        Me.CV2_DO3.Location = New System.Drawing.Point(1155, 109)
        Me.CV2_DO3.Name = "CV2_DO3"
        Me.CV2_DO3.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO3.TabIndex = 53
        Me.CV2_DO3.Text = "Complete"
        '
        'CV2_DO2
        '
        Me.CV2_DO2.Location = New System.Drawing.Point(1155, 87)
        Me.CV2_DO2.Name = "CV2_DO2"
        Me.CV2_DO2.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO2.TabIndex = 52
        Me.CV2_DO2.Text = "Busy"
        '
        'CV2_DO1
        '
        Me.CV2_DO1.Location = New System.Drawing.Point(1155, 66)
        Me.CV2_DO1.Name = "CV2_DO1"
        Me.CV2_DO1.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO1.TabIndex = 51
        Me.CV2_DO1.Text = "TR"
        '
        'CV2_DO0
        '
        Me.CV2_DO0.Location = New System.Drawing.Point(1155, 43)
        Me.CV2_DO0.Name = "CV2_DO0"
        Me.CV2_DO0.Size = New System.Drawing.Size(55, 15)
        Me.CV2_DO0.TabIndex = 50
        Me.CV2_DO0.Text = "SC"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(900, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 12)
        Me.Label1.TabIndex = 66
        Me.Label1.Text = "Step:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(935, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 12)
        Me.Label2.TabIndex = 67
        Me.Label2.Text = "Label2"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1057, 488)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 68
        Me.Button2.Text = "Step+1"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(947, 439)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 69
        Me.Button3.Text = "OUT"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(74, 488)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(611, 22)
        Me.TextBox2.TabIndex = 70
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(1057, 439)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 71
        Me.Button4.Text = "IN"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1252, 551)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CV2_DO15)
        Me.Controls.Add(Me.CV2_DO14)
        Me.Controls.Add(Me.CV2_DO13)
        Me.Controls.Add(Me.CV2_DO12)
        Me.Controls.Add(Me.CV2_DO11)
        Me.Controls.Add(Me.CV2_DO10)
        Me.Controls.Add(Me.CV2_DO9)
        Me.Controls.Add(Me.CV2_DO8)
        Me.Controls.Add(Me.CV2_DO7)
        Me.Controls.Add(Me.CV2_DO6)
        Me.Controls.Add(Me.CV2_DO5)
        Me.Controls.Add(Me.CV2_DO4)
        Me.Controls.Add(Me.CV2_DO3)
        Me.Controls.Add(Me.CV2_DO2)
        Me.Controls.Add(Me.CV2_DO1)
        Me.Controls.Add(Me.CV2_DO0)
        Me.Controls.Add(Me.CV2_DI15)
        Me.Controls.Add(Me.CV2_DI14)
        Me.Controls.Add(Me.CV2_DI13)
        Me.Controls.Add(Me.CV2_DI12)
        Me.Controls.Add(Me.CV2_DI11)
        Me.Controls.Add(Me.CV2_DI10)
        Me.Controls.Add(Me.CV2_DI9)
        Me.Controls.Add(Me.CV2_DI8)
        Me.Controls.Add(Me.CV2_DI7)
        Me.Controls.Add(Me.CV2_DI6)
        Me.Controls.Add(Me.CV2_DI5)
        Me.Controls.Add(Me.CV2_DI4)
        Me.Controls.Add(Me.CV2_DI3)
        Me.Controls.Add(Me.CV2_DI2)
        Me.Controls.Add(Me.CV2_DI1)
        Me.Controls.Add(Me.CV2_DI0)
        Me.Controls.Add(Me.CV1_DO15)
        Me.Controls.Add(Me.CV1_DO14)
        Me.Controls.Add(Me.CV1_DO13)
        Me.Controls.Add(Me.CV1_DO12)
        Me.Controls.Add(Me.CV1_DO11)
        Me.Controls.Add(Me.CV1_DO10)
        Me.Controls.Add(Me.CV1_DO9)
        Me.Controls.Add(Me.CV1_DO8)
        Me.Controls.Add(Me.CV1_DO7)
        Me.Controls.Add(Me.CV1_DO6)
        Me.Controls.Add(Me.CV1_DO5)
        Me.Controls.Add(Me.CV1_DO4)
        Me.Controls.Add(Me.CV1_DO3)
        Me.Controls.Add(Me.CV1_DO2)
        Me.Controls.Add(Me.CV1_DO1)
        Me.Controls.Add(Me.CV1_DO0)
        Me.Controls.Add(Me.CV1_DI15)
        Me.Controls.Add(Me.CV1_DI14)
        Me.Controls.Add(Me.CV1_DI13)
        Me.Controls.Add(Me.CV1_DI12)
        Me.Controls.Add(Me.CV1_DI11)
        Me.Controls.Add(Me.CV1_DI10)
        Me.Controls.Add(Me.CV1_DI9)
        Me.Controls.Add(Me.CV1_DI8)
        Me.Controls.Add(Me.CV1_DI7)
        Me.Controls.Add(Me.CV1_DI6)
        Me.Controls.Add(Me.CV1_DI5)
        Me.Controls.Add(Me.CV1_DI4)
        Me.Controls.Add(Me.CV1_DI3)
        Me.Controls.Add(Me.CV1_DI2)
        Me.Controls.Add(Me.CV1_DI1)
        Me.Controls.Add(Me.CV1_DI0)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents CV1_DI0 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI1 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI2 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI3 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI4 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI5 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI6 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI7 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI8 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI9 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI10 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI11 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI12 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI13 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI14 As System.Windows.Forms.Label
    Friend WithEvents CV1_DI15 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO15 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO14 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO13 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO12 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO11 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO10 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO9 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO8 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO7 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO6 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO5 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO4 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO3 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO2 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO1 As System.Windows.Forms.Label
    Friend WithEvents CV1_DO0 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI15 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI14 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI13 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI12 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI11 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI10 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI9 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI8 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI7 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI6 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI5 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI4 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI3 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI2 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI1 As System.Windows.Forms.Label
    Friend WithEvents CV2_DI0 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO15 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO14 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO13 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO12 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO11 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO10 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO9 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO8 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO7 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO6 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO5 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO4 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO3 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO2 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO1 As System.Windows.Forms.Label
    Friend WithEvents CV2_DO0 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button

End Class
