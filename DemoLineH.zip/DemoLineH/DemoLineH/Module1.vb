﻿Module Module1
    Structure car_point
        Dim carno As Integer
        Dim Position As Integer
        Dim AGVAction As Integer
        Dim Status As Integer
        Dim Loading As Integer
        Dim CarWork As Integer
        Dim cmdcnt As Integer


    End Structure
End Module
