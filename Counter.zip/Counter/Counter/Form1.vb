﻿Imports EasyModbus

Public Class Form1
    Private modbusClient As ModbusClient
    Private previousData As New Dictionary(Of Integer, Integer())
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        modbusClient = New ModbusClient()
        ' 設定 Modbus TCP Server 的 IP 地址和端口號
        modbusClient.IPAddress = "192.168.200.90" ' 請換成你的 Modbus TCP Server 的 IP 地址
        modbusClient.Port = 502 ' 請換成你的 Modbus TCP Server 的 Port

    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        modbusClient.Connect()

        ' 讀取保持寄存器 0 到 100 的數據
        Dim data1 As Integer() = modbusClient.ReadHoldingRegisters(0, 100)

        ' 讀取保持寄存器 1000 到 1200 的數據
        Dim data2 As Integer() = modbusClient.ReadHoldingRegisters(1000, 200)

        ' 讀取保持寄存器 2000 到 2200 的數據
        Dim data3 As Integer() = modbusClient.ReadHoldingRegisters(2000, 201)

        ' 關閉 Modbus TCP 連接
        modbusClient.Disconnect()

    End Sub

    Dim safelist As Integer()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        Dim list As String() = TextBox2.Text.Split(",")
        ReDim safelist(list.Length - 1)

        For i As Integer = 0 To list.Length - 1
            safelist(i) = Convert.ToInt32(list(i))
        Next
        modbusClient.Connect()

        ' 讀取保持寄存器 0 到 100 的數據
        Dim data1 As Integer() = modbusClient.ReadHoldingRegisters(0, 96)
        CheckAndRecordData(0, data1)
        ' 讀取保持寄存器 1000 到 1200 的數據
        Dim data2 As Integer() = modbusClient.ReadHoldingRegisters(1000, 100)
        CheckAndRecordData(1000, data2)

        Dim data3 As Integer() = modbusClient.ReadHoldingRegisters(1100, 88)
        CheckAndRecordData(1100, data3)
        ' 讀取保持寄存器 2000 到 2200 的數據
        Dim data4 As Integer() = modbusClient.ReadHoldingRegisters(2000, 122)
        CheckAndRecordData(2000, data4)
        ' 關閉 Modbus TCP 連接
        modbusClient.Disconnect()
    End Sub
    Private Sub CheckAndRecordData(ByVal startAddress As Integer, ByVal data As Integer())
        ' 檢查是否有前一次的數據
        If previousData.ContainsKey(startAddress) Then
            ' 檢查數據是否相同
            If Not Enumerable.SequenceEqual(previousData(startAddress), data) Then
                ' 如果數據不一樣，則記錄新的數據
                ' 在這裡你可以根據需要進行對新數據的處理，例如寫入檔案或顯示在 UI 上
                ' ...
                For i As Integer = 0 To data.Length - 1
                    Dim idx As Integer = Array.IndexOf(safelist, i + startAddress)
                    If Not data(i) = previousData(startAddress)(i) And idx = -1 Then
                        TextBox1.Text += (i + startAddress).ToString + ":" + previousData(startAddress)(i).ToString + "->" + data(i).ToString + vbCrLf
                    End If

                Next


                ' 更新前一次的數據
                previousData(startAddress) = data
            End If
        Else
            ' 如果之前沒有記錄過這個地址的數據，直接將數據記錄下來
            previousData.Add(startAddress, data)
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Start()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Timer1.Stop()
    End Sub
End Class
